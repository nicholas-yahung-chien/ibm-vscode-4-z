"""Module containing cached JSON schemas."""
