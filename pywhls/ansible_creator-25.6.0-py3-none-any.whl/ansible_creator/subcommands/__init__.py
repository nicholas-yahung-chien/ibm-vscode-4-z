"""A package containing all actions supported by ansible-creator."""
